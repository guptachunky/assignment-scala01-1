package edu.knoldus

class Sorting {


  def insertion(arg:Array[Int]): Array[Int]  =
  {
    val n=arg.length
    for(i<-1 to (n-1)) {
      val key = arg(i)
      var j=i-1
      while(j>=0 && arg(j)>key)
      {
        arg(j+1)=arg(j)
        j=j-1

      }
      arg(j+1)=key
}

    arg
  }


  def selection(arg : Array[Int]): Array[int] = {
    val n=arg.length
    for(i<-0 to(n-2))
    {
      var min=i
      for(j<-i+1 to (n-1))
      {
        if(arg(j)< arg(min))
        {
          min=j;
        }

      }
      val temp=arg(min)
      arg(min)=arg(i)
      arg(i)=temp
    }

    arg
  }

  def bubble(arg:Array[Int]): Array[Int]=
  {
    val n: Int = arg.length
    for(i<-0 to (n-2))
    {
      for(j<-0 to (n-i-2))
      {
        if(arg(j)>arg(j+1))
        {
          val temp=arg(j)
          arg(j)=arg(j+1)
          arg(j+1)=temp


        }


      }

    }
    arg
  }

}
