package edu.knoldus

class Searching {

  def linear(arg:Array[Int], value : Int): Boolean =
  {
    for ( i <- 0 to (arg.length - 1)) {
      if(arg(i)==value)
      {
        return true;
      }
    }
    return false;
  }



  def binary(arg:Array[Int], value : Int ,l : Int, r : Int): Boolean =
  {
    if(l<r)
    {
      val mid=l+(r-l)/2
      if(arg(mid)==value)
      {
        return true
      }
      else  if(arg(mid)>value)
      {
        return binary(arg,value,l,mid-1)
      }
      else
      {
        return binary(arg,value,mid+1,r)
      }

    }
    return false


  }


}
